//imports
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
//methods used
public class HouseholdSpending {
    private JTextField tfweek1;
    private JTextField tfweek3;
    private JTextField tfweek4;
    private JTextField tftotal;
    private JTextField tfavg;
    private JButton calculateButton;
    private JTextField tfweek2;
    private JPanel main;
    private JButton saveButton;
    private JButton updateButton;
    private JButton deleteButton;
    private JTable table1;
    private JComboBox comboBox1;

    public static void main(String[] args) {
        JFrame frame = new JFrame("HouseholdSpending");
        frame.setContentPane(new HouseholdSpending().main);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.pack();
        frame.setVisible(true);
    }
    //main function of program
    public HouseholdSpending() {
        calculateButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                //variables used in the program
                double week1,week2,week3,week4,total;
                double average;

                //getting the user input and incorporating it into the formula
                week1 = Double.parseDouble(tfweek1.getText());
                week2 = Double.parseDouble(tfweek2.getText());
                week3 = Double.parseDouble(tfweek3.getText());
                week4 = Double.parseDouble(tfweek4.getText());
                //formula to find total spending of the 4 weeks
                total = week1 + week2 + week3 + week4;
                tftotal.setText(String.valueOf(total));
                //formula to find the average spending of the 4 weeks
                average = total/4;
                tfavg.setText(String.valueOf(average));

            }
        });
    }
}
